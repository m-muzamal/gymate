export const data = [
    {
        title: "Legs & shoulders",
        types: 10,
        time: 60,
        bgColor: '',
        value: true
    },
    {
        title: "Cheest & Back",
        types: 8,
        time: 60,
        bgColor: '',
        value: true
    },
    {
        title: "Arams & Sholders",
        types: 7,
        time: 60,
        bgColor: '',
        value: true
    },
    {
        title: "Triceps & Abs",
        types: 8,
        time: 60,
        bgColor: '',
        value: true
    },
    {
        title: "Lats & Biceps",
        types: 7,
        time: 60,
        bgColor: '',
        value: true
    },
    {
        title: "Whole Body",
        types: 10,
        time: 60,
        bgColor: '',
        value: true
    },
]

localStorage.setItem("plan", JSON.stringify(data));
